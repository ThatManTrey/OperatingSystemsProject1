/*
 * GeekOS C code entry point
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003, Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 * Copyright (c) 2004, Iulian Neamtiu <neamtiu@cs.umd.edu>
 * $Revision: 1.51 $
 * 
 * Copyright (c) 2004 - 2011, Timothy Henry <thenry@cs.uri.edu>
 *
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#include <geekos/bootinfo.h>	// for memory size
#include <geekos/memory.h>		// memory manager functions
#include <geekos/screen.h>		// screen constants and functions
#include <geekos/tss.h>			// TSS structure definiton
#include <geekos/interrupts.h>	// interrupt functions & Interrupt_State struct definition
#include <geekos/kthread.h>		// process management functions
#include <geekos/traps.h>		// trap / system call functionality
#include <geekos/timer.h>		// timer initialization
#include <geekos/keyboard.h>	// keyboard constants and functions

/*
 * Kernel C code entry point.
 * Initializes kernel subsystems, mounts filesystems,
 * and spawns init process.
 */
void Main(struct Boot_Info* bootInfo)
{
    Init_BSS();			// clear kernel BSS (memory.c)
    Init_Screen();		// clear display (screen.c)
    Init_Mem(bootInfo);	// initialize memory manager 
    Init_TSS();			// initialize kernel TSS (tss.c)
    Init_Interrupts();	// initialize interrupt handlers (interrupts.c)
    Init_Scheduler();	// initalize and spawn scheduler thread (kthread.c)
    Init_Traps();		// initialize system call traps (traps.c)
    Init_Timer();		// initialize system timer (timer.c)
    Init_Keyboard();	// initialize keyboard (keyboard.c)


    Set_Current_Attr(ATTRIB(BLACK, GREEN|BRIGHT));
    Print("Welcome to GeekOS!\n");
    Set_Current_Attr(ATTRIB(BLACK, GRAY));

    TODO("Start a kernel thread to echo pressed keys!");
	
    /* Now this thread is done. */
    Exit(0);
}
